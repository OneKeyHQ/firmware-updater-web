import EventEmitter from 'events';

import { createCoreApi, createProtocolAwareCall } from './inject';
import { unregisterFirmwareUpdateHostBinding } from './api/firmware/FirmwareHostBinding';

import type { ConnectSettings } from './types/settings';
import type { CoreApi } from './types/api';
import type { LowLevelCoreApi } from './lowLevelInject';

export interface TopLevelInjectApi {
  init: CoreApi['init'];
  call: CoreApi['call'];
}

const eventEmitter = new EventEmitter();

export const topLevelInject = () => {
  let lowLevelApi: LowLevelCoreApi | undefined;
  const call = (params: any) => {
    if (!lowLevelApi) return Promise.resolve(undefined);
    return lowLevelApi.call(params);
  };
  const protocolAwareCall = createProtocolAwareCall(call);
  const api: CoreApi = {
    on: <T extends string, P extends (...args: any[]) => any>(type: T, fn: P) => {
      eventEmitter.on(type, fn);
    },

    emit: (eventName: string, ...args: any[]) => {
      eventEmitter.emit(eventName, ...args);
    },

    off: (type, fn) => {
      eventEmitter.emit(type, fn);
    },

    init: (settings, hardwareLowLeverApi) => {
      lowLevelApi = hardwareLowLeverApi;
      return lowLevelApi?.init(settings) ?? Promise.resolve(false);
    },

    call: protocolAwareCall.call,

    setDeviceConnectProtocol: protocolAwareCall.setDeviceConnectProtocol,

    ...createCoreApi(protocolAwareCall.call),

    removeAllListeners: type => {
      eventEmitter.removeAllListeners(type);
      lowLevelApi?.removeAllListeners(type);
    },

    dispose: async () => {
      unregisterFirmwareUpdateHostBinding();
      await lowLevelApi?.dispose();
    },

    uiResponse: response => lowLevelApi?.uiResponse(response),

    cancel: (connectId?: string) => lowLevelApi?.cancel(connectId),

    updateSettings: settings => lowLevelApi?.updateSettings(settings) ?? Promise.resolve(false),

    switchTransport: (env: ConnectSettings['env']) =>
      lowLevelApi?.switchTransport(env) ?? Promise.resolve({ success: false }),
  };

  return api;
};
