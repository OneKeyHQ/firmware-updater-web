import { UI_REQUEST } from '../../constants/ui-request';
import { serializedPath, validatePath } from '../helpers/pathUtils';
import { BaseMethod } from '../BaseMethod';
import { validateParams, validateResult } from '../helpers/paramsValidator';

import type { KaspaGetAddress as HardwareKaspaGetAddress } from '@onekeyfe/hd-transport';
import type { KaspaAddress, KaspaGetAddressParams } from '../../types';

export default class KaspaGetAddress extends BaseMethod<HardwareKaspaGetAddress[]> {
  getSupportedProtocols() {
    return ['V1', 'V2'] as const;
  }

  hasBundle = false;

  init() {
    this.checkDeviceId = true;
    this.allowDeviceMode = [...this.allowDeviceMode, UI_REQUEST.NOT_INITIALIZE];

    this.hasBundle = !!this.payload?.bundle;
    const payload = this.hasBundle ? this.payload : { bundle: [this.payload] };

    // check payload
    validateParams(payload, [{ name: 'bundle', type: 'array' }]);

    // init params
    this.params = [];
    payload.bundle.forEach((batch: KaspaGetAddressParams) => {
      const addressN = validatePath(batch.path, 3);

      validateParams(batch, [
        { name: 'path', required: true },
        { name: 'showOnOneKey', type: 'boolean' },
        { name: 'prefix', type: 'string' },
        { name: 'scheme', type: 'string' },
        { name: 'useTweak', type: 'boolean' },
      ]);

      const showOnOneKey = batch.showOnOneKey ?? true;

      this.params.push({
        address_n: addressN,
        show_display: showOnOneKey,
        prefix: batch.prefix,
        scheme: batch.scheme,
        use_tweak: batch.useTweak,
      });
    });
  }

  getVersionRange() {
    return {
      model_mini: {
        min: '3.0.0',
      },
      model_touch: {
        min: '4.3.0',
      },
    };
  }

  getUseTweakVersionRange() {
    return {
      pro: {
        min: '4.14.0',
      },
      model_classic1s: {
        min: '3.12.0',
      },
      model_pro2: {
        min: '0.0.0',
      },
    };
  }

  async run() {
    this.checkFeatureVersionLimit(
      // exists use_tweak is false check firmware version
      () => this.params.some(param => param.use_tweak === false),
      () => this.getUseTweakVersionRange(),
      {
        strictCheckDeviceSupport: true,
      }
    );

    const responses: KaspaAddress[] = [];

    for (let i = 0; i < this.params.length; i++) {
      const param = this.params[i];
      const res = await this.device.commands.typedCall('KaspaGetAddress', 'KaspaAddress', {
        ...param,
      });

      const { address } = res.message;

      const result = {
        path: serializedPath(param.address_n),
        address,
      };
      responses.push(result);
      this.postPreviousAddressMessage(result);
    }

    validateResult(responses, ['address'], {
      expectedLength: this.params.length,
    });

    return Promise.resolve(this.hasBundle ? responses : responses[0]);
  }
}
