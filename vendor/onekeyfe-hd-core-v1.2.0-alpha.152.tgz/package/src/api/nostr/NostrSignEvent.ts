import { ERRORS, HardwareErrorCode } from '@onekeyfe/hd-shared';

import { UI_REQUEST } from '../../constants/ui-request';
import { serializedPath, validatePath } from '../helpers/pathUtils';
import { BaseMethod } from '../BaseMethod';
import { validateParams } from '../helpers/paramsValidator';
import { validateEvent } from './helper';
import { bytesToHex, hexToBytes } from '../helpers/hexUtils';

import type { NostrSignEvent as SignEvent } from '@onekeyfe/hd-transport';

export default class NostrSignEvent extends BaseMethod<SignEvent> {
  getSupportedProtocols() {
    return ['V1', 'V2'] as const;
  }

  hasBundle = false;

  init() {
    this.checkDeviceId = true;
    this.allowDeviceMode = [...this.allowDeviceMode, UI_REQUEST.NOT_INITIALIZE];
    this.allowUsePreInitialize = true;

    const { payload } = this;
    if (!validateEvent(payload.event)) {
      throw ERRORS.TypedError(
        HardwareErrorCode.CallMethodInvalidParameter,
        `Can't serialize event with wrong or missing properties`
      );
    }
    validateParams(payload, [{ name: 'path', required: true }]);
    const addressN = validatePath(payload.path, 5);

    this.params = {
      address_n: addressN,
      event: bytesToHex(Buffer.from(JSON.stringify(payload.event, null, 0), 'utf-8')),
    };
  }

  getVersionRange() {
    return {
      model_mini: {
        min: '3.6.0',
      },
      model_touch: {
        min: '4.7.0',
      },
    };
  }

  async run() {
    const { message } = await this.device.commands.typedCall(
      'NostrSignEvent',
      'NostrSignedEvent',
      this.params
    );

    try {
      const signedEvent = Buffer.from(hexToBytes(message.event)).toString('utf-8');
      const event = JSON.parse(signedEvent);
      return {
        path: serializedPath(this.params.address_n),
        rawTx: message.event,
        event,
      };
    } catch (e) {
      throw ERRORS.TypedError(HardwareErrorCode.CallMethodError, 'Failed to parse signed event', e);
    }
  }
}
