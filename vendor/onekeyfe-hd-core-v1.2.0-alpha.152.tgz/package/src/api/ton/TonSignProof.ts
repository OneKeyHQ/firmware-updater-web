import { UI_REQUEST } from '../../constants/ui-request';
import { validatePath } from '../helpers/pathUtils';
import { BaseMethod } from '../BaseMethod';
import { validateParams } from '../helpers/paramsValidator';

import type { TonSignProof as HardwareTonSignProof } from '@onekeyfe/hd-transport';
import type { TonSignProofParams } from '../../types';

export default class TonSignProof extends BaseMethod<HardwareTonSignProof> {
  getSupportedProtocols() {
    return ['V1', 'V2'] as const;
  }

  init() {
    this.strictCheckDeviceSupport = true;
    this.checkDeviceId = true;
    this.allowDeviceMode = [...this.allowDeviceMode, UI_REQUEST.NOT_INITIALIZE];
    this.allowUsePreInitialize = true;

    // init params
    validateParams(this.payload, [
      { name: 'path', required: true },
      { name: 'appdomain', type: 'string' },
      { name: 'comment', type: 'string' },
      { name: 'expireAt' },
      { name: 'walletVersion' },
      { name: 'walletId', type: 'number' },
      { name: 'workchain' },
      { name: 'isBounceable', type: 'boolean' },
      { name: 'isTestnetOnly', type: 'boolean' },
    ]);

    const { path } = this.payload as TonSignProofParams;
    const addressN = validatePath(path, 3);

    this.params = {
      address_n: addressN,
      appdomain: this.payload.appdomain,
      comment: this.payload.comment,
      expire_at: this.payload.expireAt,
      wallet_version: this.payload.walletVersion,
      wallet_id: this.payload.walletId,
      workchain: this.payload.workchain,
      is_bounceable: this.payload.isBounceable,
      is_testnet_only: this.payload.isTestnetOnly,
    };
  }

  getVersionRange() {
    return {
      model_pro2: {
        min: '0.0.0',
      },
      model_touch: {
        min: '4.10.0',
      },
      model_classic1s: {
        min: '3.10.0',
      },
    };
  }

  async run() {
    const res = await this.device.commands.typedCall('TonSignProof', 'TonSignedProof', {
      ...this.params,
    });

    return Promise.resolve(res.message);
  }
}
