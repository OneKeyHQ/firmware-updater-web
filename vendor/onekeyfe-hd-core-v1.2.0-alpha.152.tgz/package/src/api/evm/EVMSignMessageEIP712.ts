import { UI_REQUEST } from '../../constants/ui-request';
import { validatePath } from '../helpers/pathUtils';
import { BaseMethod } from '../BaseMethod';
import { validateParams } from '../helpers/paramsValidator';
import { formatAnyHex } from '../helpers/hexUtils';

import type { EthereumSignMessageEIP712 } from '@onekeyfe/hd-transport';
import type { DeviceFirmwareRange } from '../../types';

/**
 * @deprecated Use EVMSignTypedData instead.
 */
export default class EVMSignMessageEIP712 extends BaseMethod<EthereumSignMessageEIP712> {
  init() {
    this.checkDeviceId = true;
    this.allowDeviceMode = [...this.allowDeviceMode, UI_REQUEST.NOT_INITIALIZE];
    this.allowUsePreInitialize = true;

    validateParams(this.payload, [
      { name: 'path', required: true },
      { name: 'domainHash', type: 'hexString', required: true },
      { name: 'messageHash', type: 'hexString', required: true },
    ]);

    const { path, domainHash, messageHash } = this.payload;

    const addressN = validatePath(path, 3);

    this.params = {
      address_n: addressN,
      domain_hash: formatAnyHex(domainHash),
      message_hash: formatAnyHex(messageHash),
    };
  }

  getVersionRange(): DeviceFirmwareRange {
    return {
      model_mini: {
        min: '2.1.9',
      },
      model_classic1s: {
        min: '3.14.0',
      },
    };
  }

  async run() {
    this.assertProtocolSupported(this.device.getProtocol(), this.device.getCurrentFirmwareType());

    const res = await this.device.commands.typedCall(
      'EthereumSignMessageEIP712',
      'EthereumMessageSignature',
      {
        ...this.params,
      }
    );

    return Promise.resolve(res.message);
  }
}
